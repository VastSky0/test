echo -e "\e[1;93m Khởi động nekobox sau 3 giây nữa...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 2 giây...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 1 giây...\e[0m"
sleep 0.95
echo -e"\e[1;32m Còn 0 giây...\e[0m"
sleep 0.15
clear