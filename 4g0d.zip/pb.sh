echo -e "\e[1;93mĐang kiểm tra phiên bản\e[0m"
sleep 1
v='1.0'
ver=$(curl -s https://raw.githubusercontent.com/VastSky0/4g0d/main/ver)
echo -e "\e[1;94mPhiên bản hiện tại: \e[0m" $v
if [ $v = $ver ]
then
echo -e "\e[1;91mBạn đang ở phiên bản mới nhất\e[0m"
else
echo -e "\e[1;91mCó bản cập nhật mới, sẽ tự động cập nhật sau 2s\e[0m"
sleep 2
echo -e "\e[1;93mCập nhật packages\e[0m"
apt update && apt upgrade -y
clear
echo -e "\e[1;93mĐang cài đặt\e[0m"
sleep 1
cd && cd && cd $HOME && cd /data/data/com.termux/files/usr/bin/ && pkg install wget -y && wget https://github.com/VastSky0/4g0d/raw/main/4g0d.zip && unzip 4g0d.zip && chmod a+x *
clear
cd && cd && cd $HOME && cd /data/data/com.termux/files/usr/etc/ && pkg install wget -y && wget https://github.com/VastSky0/4g0d/raw/main/tb && mv tb motd
clear
cd && cd && cd $HOME && cd /data/data/com.termux/files/usr/bin/ && pkg install wget -y && wget https://github.com/VastSky0/4g0d/raw/main/rtb && chmod +x * && mv rtb login
clear
sleep 1
echo -e "\e[1;92mĐã cài đặt thành công\e[0m"
sleep 1
clear
termux-wake-lock
clear
sleep 1
login
fi