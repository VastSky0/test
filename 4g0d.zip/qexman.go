echo -e "\e[1;33m Đang tắt nekobox...\e[0m"
echo -e "\e[1;33m Và sẽ thoát termux sau 4 giây nữa...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 3 giây...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 2 giây...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 1 giây...\e[0m"
sleep 0.15
clear